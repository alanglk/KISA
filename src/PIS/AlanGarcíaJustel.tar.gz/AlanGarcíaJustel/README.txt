Procesamiento de Imágen y Señal
Alan García Justel
2024-2025

Los archivos y carpetas de datos del repositorio de código de la asignatura se copiaron dentro de la carpeta "labs". 
No se han incluido los ficheros de datos para reducir el tamaño del entregable. 
